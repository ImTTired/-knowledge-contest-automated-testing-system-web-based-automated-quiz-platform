@echo off
chcp 65001 >nul
cd /d "%~dp0"
"%~dp0QuizAssistant.exe" --custom-bank
